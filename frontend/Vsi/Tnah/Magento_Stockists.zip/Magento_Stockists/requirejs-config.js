var config = {
    map: {
        '*': {
            limesharp_stockists: 'Limesharp_Stockists/js/limesharp_stockists',
            async: 'Limesharp_Stockists/js/async',
            stockists_countries: 'Limesharp_Stockists/js/stockists_countries',
            stockists_mapstyles: 'Limesharp_Stockists/js/stockists_mapstyles',
            stockists_search: 'Limesharp_Stockists/js/stockists_search',
            stockists_widget: 'Limesharp_Stockists/js/stockists_widget',
            stockists_geolocation: 'Limesharp_Stockists/js/stockists_geolocation',
            stockists_slick: 'Limesharp_Stockists/js/stockists_slick',
            stockists_individual_stores: 'Limesharp_Stockists/js/limesharp_individual_stores'
        }
    }
};
